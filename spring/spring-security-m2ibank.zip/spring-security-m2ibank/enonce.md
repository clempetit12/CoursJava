## TP Spring Security 

## Opération à faire : 

- Rendre le projet fonctionnel sans sécurité aux préalables.
- Mettre en place les éléments de sécurité suivant : 
    - Être authentifié et avoir le rôle USER pour accéder à :
        - Account, Loans, Balance et Cards.
    - Être authentifié et avoir le rôle ADMIN pour accéder à :
        - Balance.
    - Tout le monde peut accéder à  :
        - notices, contact, login et register